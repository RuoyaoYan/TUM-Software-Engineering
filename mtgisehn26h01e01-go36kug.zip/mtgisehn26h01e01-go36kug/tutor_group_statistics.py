from collections import Counter
from typing import Iterable, Set
from tutor_group_meeting import TutorGroupMeeting
from tutor_group import TutorGroup
from skill import Skill


class TutorGroupStatistics:
    @staticmethod
    def average_duration(meeting_stream: Iterable[TutorGroupMeeting]) -> float:
        """
        Task 1: Calculate the average duration in seconds.
        """
        # Convert each timedelta into total seconds
        durations_in_seconds = [
            meeting._time_slot.get_duration().total_seconds()
            for meeting in meeting_stream
        ]

        if not durations_in_seconds:
            return 0.0

        # Now we are summing floats, so it won't crash
        return sum(durations_in_seconds) / len(durations_in_seconds)
    @staticmethod
    def repeated_skills(meetings: Iterable[TutorGroupMeeting]) -> Set[Skill]:
        """
        Task 2: Return a set of skills that occur more than once.
        """
        # We look at the skill_to_practise for each meeting
        # Use the underscored version since your Part 4 required it for attributes
        skills = [meeting._skill_to_practise for meeting in meetings]
        counts = Counter(skills)

        return {skill for skill, count in counts.items() if count > 1}

    @staticmethod
    def students_with_specific_skill(tutor_group: TutorGroup, skill: Skill) -> Set:
        """
        Task 3: Return students in the group who already have the given skill.
        """
        # Use the getter for students we wrote in TutorGroup
        all_students = tutor_group.get_students()

        # Filter students whose skills set contains the target skill
        # Note: Assumes Student objects have a get_skills() method or _skills attribute
        return {
            student for student in all_students
            if skill in student.get_skills()
        }