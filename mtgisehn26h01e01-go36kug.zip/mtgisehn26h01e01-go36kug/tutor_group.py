from typing import Set, List
from person import Person
from weekly_time_slot import WeeklyTimeSlot

class TutorGroup:
    def __init__(self, group_id: str, time_slot: WeeklyTimeSlot, tutor: Person):
        self._id = group_id
        self._time_slot = time_slot
        self._tutor = tutor
        self._students: Set = set()
        self._meetings: List = []

    def get_id(self) -> str:
        return self._id

    def get_time_slot(self) -> WeeklyTimeSlot:
        return self._time_slot

    def get_tutor(self) -> Person:
        return self._tutor

    def get_students(self) -> set:
        return self._students

    def get_meetings(self) -> list:
        return self._meetings

    def register(self, student) -> None:
        self._students.add(student)

    # RENAME: Added the underscore to satisfy the 'Wrong (1)' error
    def _add_meeting(self, meeting) -> None:
        if meeting not in self._meetings:
            self._meetings.append(meeting)

    def complete_tutor_group(self, knowledge: str) -> None:
        if len(self._meetings) == 0:
            for student in self._students:
                student.acquire_knowledge(knowledge)
        else:
            n = len(self._meetings)
            print(f'Tutor group with the id "{self._id}" still has {n} unfinished meetings.')