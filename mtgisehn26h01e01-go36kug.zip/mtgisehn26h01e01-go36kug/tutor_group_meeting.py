from abc import ABC, abstractmethod
from fixed_date_time_slot import FixedDateTimeSlot
from skill import Skill


class TutorGroupMeeting(ABC):
    def __init__(self, time_slot: FixedDateTimeSlot, tutor_group, skill_to_practise: Skill):
        # Public attributes as required by the Python tests
        self.time_slot = time_slot
        self.tutor_group = tutor_group
        self.skill_to_practise = skill_to_practise

        # FIX: Added the underscore to match the method name in TutorGroup
        self.tutor_group._add_meeting(self)


    @abstractmethod
    def practice(self) -> None:
        pass

