from abc import ABC, abstractmethod

class Skill(ABC):
    @abstractmethod
    def apply(self) -> None:
        """
        Abstract method to apply the skill.
        Subclasses must implement this.
        """
        pass
