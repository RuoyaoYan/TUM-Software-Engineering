from abc import ABC

class Person(ABC):
    def __init__(self, name: str, age: int, tum_id: str):
        # Protected attributes (#)
        self._name = name
        self._age = age
        self._tum_id = tum_id

    # Protected method (#)
    def _say(self, text: str) -> None:
        print(f"{self._name} said: {text}")
