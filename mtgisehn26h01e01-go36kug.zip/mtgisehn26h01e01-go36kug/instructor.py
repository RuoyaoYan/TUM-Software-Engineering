from person import Person

class Instructor(Person):
    def __init__(self, name: str, age: int, tum_id: str):
        super().__init__(name, age, tum_id)

    def teach(self, content: str) -> None:
        # 1. 'content' here matches the 'content' in the parentheses above
        # 2. We use 'self.say' (public) instead of 'self._say' to match Task 4
        self._say(f'Please learn "{content}"')

