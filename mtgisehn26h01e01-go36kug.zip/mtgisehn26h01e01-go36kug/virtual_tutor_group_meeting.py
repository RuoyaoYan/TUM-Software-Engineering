# from tutor_group_meeting import TutorGroupMeeting
#
#
# class VirtualTutorGroupMeeting(TutorGroupMeeting):
#     def __init__(self, time_slot, tutor_group, skill_to_practise, url: str):
#         # Ensure parent constructor is called correctly
#         super().__init__(time_slot, tutor_group, skill_to_practise)
#         self._url = url
#
#     def get_url(self) -> str:
#         return self._url
#
#     def practice(self) -> None:
#         # We check if the attribute exists with or without an underscore
#         # to prevent the AttributeError regardless of the parent's setup.
#         group = getattr(self, '_tutor_group', getattr(self, 'tutor_group', None))
#         skill = getattr(self, '_skill_to_practise', getattr(self, 'skill_to_practise', None))
#
#         if group:
#             tutor = group.get_tutor()
#             # Requirement: Instructor says greeting
#             tutor._say(f"Thank you for joining using {self._url} today.")
#
#             # Students learn the skill
#             for student in group.get_students():
#                 student.learn_skill(skill)
#
#             # Meeting removes itself from the list
#             group.get_meetings().remove(self)
#
#             # Final goodbye
#             tutor._say("See you next time!")
#
from tutor_group_meeting import TutorGroupMeeting


class VirtualTutorGroupMeeting(TutorGroupMeeting):
    def __init__(self, time_slot, tutor_group, skill_to_practise, url: str):
        # 1. Initialize the parent class
        super().__init__(time_slot, tutor_group, skill_to_practise)

        self._time_slot = time_slot
        self._tutor_group = tutor_group
        self._skill_to_practise = skill_to_practise
        self._url = url

    def get_url(self) -> str:
        return self._url

    def practice(self) -> None:

        tutor = self._tutor_group.get_tutor()

        # Requirement: Instructor says the specific joining message
        tutor._say(f"Thank you for joining using {self._url} today.")

        # Every participating student learns the skill
        for student in self._tutor_group.get_students():
            student.learn_skill(self._skill_to_practise)

        # The meeting removes itself from the tutor group's meetings list
        self._tutor_group.get_meetings().remove(self)
        tutor._say("See you next time!")