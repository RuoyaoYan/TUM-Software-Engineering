from datetime import date, time
from time_slot import TimeSlot

class FixedDateTimeSlot(TimeSlot):
    def __init__(self, slot_date: date, start_time: time, end_time: time):
        # super() sends the times up to the TimeSlot class
        super().__init__(start_time, end_time)
        # UML '-' means private/read-only for this class
        self._date = slot_date

    def get_date(self) -> date:
        return self._date