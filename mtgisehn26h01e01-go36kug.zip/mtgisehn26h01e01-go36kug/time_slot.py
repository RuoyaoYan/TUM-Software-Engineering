from abc import ABC
from datetime import time, datetime, date, timedelta

class TimeSlot(ABC):
    def __init__(self, start_time: time, end_time: time):
        # UML '#' means protected, so we use a single leading underscore
        self._start_time = start_time
        self._end_time = end_time

    def get_duration(self) -> timedelta:
        """
        Calculates the duration between start and end time.
        Uses date.min as a neutral anchor to allow time subtraction.
        """
        start_dt = datetime.combine(date.min, self._start_time)
        end_dt = datetime.combine(date.min, self._end_time)
        return end_dt - start_dt