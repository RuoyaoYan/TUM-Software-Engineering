from person import Person
from study_level import StudyLevel
from skill import Skill
from typing import Set

class Student(Person):
    def __init__(self, name: str, age: int, tum_id: str, 
                 matriculation_number: str, study_level: StudyLevel, semester: int):
        super().__init__(name, age, tum_id)
        self._matriculation_number = matriculation_number
        self._study_level = study_level
        self._semester = semester
        # Sets must start out empty
        self._knowledge: Set[str] = set()
        self._skills: Set[Skill] = set()

    def get_matriculation_number(self) -> str:
        return self._matriculation_number

    def get_study_level(self) -> StudyLevel:
        return self._study_level

    def get_semester(self) -> int:
        return self._semester

    def get_knowledge(self) -> Set[str]:
        return self._knowledge

    def get_skills(self) -> Set[Skill]:
        return self._skills

    def learn_skill(self, skill: Skill) -> None:
        self._skills.add(skill)

    def acquire_knowledge(self, knowledge: str) -> None:
        self._knowledge.add(knowledge)