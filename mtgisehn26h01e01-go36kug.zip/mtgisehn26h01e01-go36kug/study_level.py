from enum import Enum

class StudyLevel(Enum):
    BACHELOR = "BACHELOR"
    MASTER = "MASTER"
