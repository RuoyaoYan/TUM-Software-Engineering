class TemperatureConverter:
    KELVIN_CONSTANT: float = 273.15

    def __init__(self):
        raise TypeError("TemperatureConverter is a static class and cannot be instantiated.")
    
    @staticmethod
    def convert_celsius_to_fahrenheit(temperature_celsius: float) -> float:
        return (temperature_celsius * 9.0 / 5.0) + 32.0
    
    @staticmethod
    def convert_fahrenheit_to_celsius(temperature_fahrenheit: float) -> float:
        return (temperature_fahrenheit - 32.0) * 5.0 / 9.0
    
    @staticmethod
    def convert_celsius_to_kelvin(temperature_celsius: float) -> float:
        return temperature_celsius + TemperatureConverter.KELVIN_CONSTANT

    @staticmethod
    def convert_kelvin_to_celsius(temperature_kelvin: float) -> float:
        return temperature_kelvin - TemperatureConverter.KELVIN_CONSTANT