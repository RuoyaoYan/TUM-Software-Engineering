from .temperature_gui import TemperatureGUI
from .temperature_model import TemperatureModel
from .temperature_converter import TemperatureConverter


class FahrenheitGUI(TemperatureGUI):

    def __init__(self, model: TemperatureModel, x: int, y: int):
        super().__init__("Fahrenheit Temperature", model, x, y)
        self.add_raise_temp_listener(lambda: self.get_model().increase_fahrenheit(1.0))
        self.add_lower_temp_listener(lambda: self.get_model().increase_fahrenheit(-1.0))
        self.add_display_listener(lambda: self.get_model().set_temperature_fahrenheit(self.get_display()))

    def on_update(self, new_state: float) -> None:
        self.set_display(str(TemperatureConverter.convert_celsius_to_fahrenheit(new_state)))
