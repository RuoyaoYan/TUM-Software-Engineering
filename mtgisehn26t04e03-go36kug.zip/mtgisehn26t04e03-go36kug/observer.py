from abc import ABC, abstractmethod
from typing import Generic, TypeVar

T = TypeVar('T')

class Observer(ABC, Generic[T]):
    @abstractmethod
    def on_update(self, data: T) -> None: ...
        