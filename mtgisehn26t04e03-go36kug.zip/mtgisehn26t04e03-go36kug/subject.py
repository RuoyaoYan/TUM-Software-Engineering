from abc import ABC, abstractmethod
from typing import Generic, TypeVar
from .observer import Observer

T = TypeVar('T')

class Subject(ABC, Generic[T]):
    @abstractmethod
    def __init__(self) -> None:
        self.__observers: set[Observer[T]] = set()

    def add_observer(self, observer: Observer[T]) -> None:
        if observer is None:
            raise ValueError("Observer cannot be None")
        self.__observers.add(observer)
    
    def remove_observer(self, observer: Observer[T]) -> None:
        if observer is None:
            raise ValueError("Observer cannot be None")
        self.__observers.discard(observer)

    def _notify_observers(self, new_state: T) -> None:
        for observer in self.__observers:
            observer.on_update(new_state)
