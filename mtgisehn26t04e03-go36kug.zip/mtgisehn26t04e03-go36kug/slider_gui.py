from typing import Optional
import tkinter as tk
from .observer import Observer
from .temperature_model import TemperatureModel


class SliderGUI(Observer[float]):

    MIN_VALUE = -20
    MAX_VALUE = 150
    WIDTH = 300
    HEIGHT = 100

    def __init__(self, model: TemperatureModel, x: int, y: int):
        self.__model = model
        self.__x = x
        self.__y = y

        self.__update_by_subject: bool = False 
        self._window: Optional[tk.Toplevel] = None
        self._slider: Optional[tk.Scale] = None

        self._create_ui()
        self.__model.add_observer(self)

    def _create_ui(self) -> None:
        self._window = tk.Toplevel()
        self._window.title("Temperature Slider")
        self._window.geometry(f"{self.WIDTH}x{self.HEIGHT}+{self.__x}+{self.__y}")
        self._window.protocol("WM_DELETE_WINDOW", self._on_close)

        self._slider = tk.Scale(
            self._window,
            from_=self.MIN_VALUE,
            to=self.MAX_VALUE,
            orient=tk.HORIZONTAL,
            command= self._on_slide
        )
        self._slider.pack(fill=tk.BOTH, expand=True)

    def _on_close(self) -> None:
        self._window.destroy()
        import sys
        sys.exit(0)

    def _on_slide(self, value: str) -> None:
        if not self.__update_by_subject:
            self.__model.set_temperature_celsius(float(value))
        
    def on_update(self, new_state: float) -> None:
        self.__update_by_subject = True
        self._slider.set(new_state)
        self.__update_by_subject = False