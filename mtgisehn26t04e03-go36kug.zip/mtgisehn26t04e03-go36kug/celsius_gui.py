from .temperature_gui import TemperatureGUI
from .temperature_model import TemperatureModel

class CelsiusGUI(TemperatureGUI):

    def __init__(self, model: TemperatureModel, x: int, y: int):
        super().__init__("Celsius Temperature", model, x, y)
        self.add_raise_temp_listener(lambda:self.get_model().increase_celsius(1.0))
        self.add_lower_temp_listener(lambda:self.get_model().increase_celsius(-1.0))
        self.add_display_listener(lambda:self.get_model().set_temperature_celsius(self.get_display()))

    def on_update(self, temp: float) -> None:
        self.set_display(str(temp))