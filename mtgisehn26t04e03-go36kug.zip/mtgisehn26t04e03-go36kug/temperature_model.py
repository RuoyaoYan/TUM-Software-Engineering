from .subject import Subject
from .temperature_converter import TemperatureConverter


class TemperatureModel(Subject[float]):
    def __init__(self):
        super().__init__()
        self.__temperature_celsius: float = 0.0

    def set_temperature_fahrenheit(self, temperature_fahrenheit: float) -> None:
        self.set_temperature_celsius(TemperatureConverter.convert_fahrenheit_to_celsius(temperature_fahrenheit))


    def set_temperature_celsius(self, temperature_celsius: float) -> None:
        self.__temperature_celsius = temperature_celsius
        self._notify_observers(temperature_celsius)

    def increase_fahrenheit(self, amount: float) -> None:
        current_fahrenheit = TemperatureConverter.convert_celsius_to_fahrenheit(self.__temperature_celsius)
        new_fahrenheit = current_fahrenheit + amount
        self.set_temperature_celsius(TemperatureConverter.convert_fahrenheit_to_celsius(new_fahrenheit))

    def increase_celsius(self, amount: float) -> None:
        self.set_temperature_celsius(self.__temperature_celsius + amount)

    def set_temperature_kelvin(self, temperature_kelvin: float) -> None:
        self.set_temperature_celsius(TemperatureConverter.convert_kelvin_to_celsius(temperature_kelvin))

    def increase_kelvin(self, amount: float) -> None:
        current_kelvin = TemperatureConverter.convert_celsius_to_kelvin(self.__temperature_celsius)
        self.set_temperature_celsius(TemperatureConverter.convert_kelvin_to_celsius(current_kelvin + amount))