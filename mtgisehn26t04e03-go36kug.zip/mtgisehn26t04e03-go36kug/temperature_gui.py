import tkinter as tk
from abc import abstractmethod
from typing import Callable, Optional
from .observer import Observer
from .temperature_model import TemperatureModel


class TemperatureGUI(Observer[float]):

    WIDTH = 220
    HEIGHT = 110

    def __init__(self, label: str, model: TemperatureModel, x: int, y: int):
        self.__model = model
        self.__label = label
        self.__x = x
        self.__y = y
        self._window: Optional[tk.Toplevel] = None
        self._display: Optional[tk.Entry] = None
        self._raise_btn: Optional[tk.Button] = None
        self._lower_btn: Optional[tk.Button] = None
        self._create_ui()
        self.__model.add_observer(self)

    def _create_ui(self) -> None:
        self._window = tk.Toplevel()
        self._window.title(self.__label)
        self._window.geometry(f"{self.WIDTH}x{self.HEIGHT}+{self.__x}+{self.__y}")
        self._window.protocol("WM_DELETE_WINDOW", self._on_close)

        frame = tk.Frame(self._window, padx=4, pady=4)
        frame.pack(fill=tk.BOTH, expand=True)

        tk.Label(frame, text=self.__label).pack(side=tk.TOP)

        self._display = tk.Entry(frame)
        self._display.pack(fill=tk.X, pady=2)
        self._display.bind("<Return>", lambda e: self._on_enter())

        btn_frame = tk.Frame(frame)
        btn_frame.pack(side=tk.BOTTOM)
        self._lower_btn = tk.Button(btn_frame, text="Lower", command=self._on_lower)
        self._lower_btn.pack(side=tk.LEFT)
        self._raise_btn = tk.Button(btn_frame, text="Raise", command=self._on_raise)
        self._raise_btn.pack(side=tk.LEFT)

    def _on_close(self) -> None:
        import sys
        self._window.destroy()
        sys.exit(0)

    def _on_enter(self) -> None:
        pass  
    def _on_raise(self) -> None:
        pass  

    def _on_lower(self) -> None:
        pass  

    def add_display_listener(self, action: Callable[[], None]) -> None:
        self._display.bind("<Return>", lambda e: action())

    def add_raise_temp_listener(self, action: Callable[[], None]) -> None:
        self._raise_btn.config(command=action)

    def add_lower_temp_listener(self, action: Callable[[], None]) -> None:
        self._lower_btn.config(command=action)

    def set_display(self, value: str) -> None:
        self._display.delete(0, tk.END)
        self._display.insert(0, value)

    def get_display(self) -> float:
        try:
            return float(self._display.get())
        except ValueError:
            return 0.0

    def get_model(self) -> TemperatureModel:
        return self.__model

    @abstractmethod
    def on_update(self, new_state: float) -> None:
        pass
