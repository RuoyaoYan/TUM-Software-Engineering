import tkinter as tk
from .temperature_model import TemperatureModel
from .slider_gui import SliderGUI
from .fahrenheit_gui import FahrenheitGUI
from .gauge_gui import GaugeGUI
from .celsius_gui import CelsiusGUI
from .kelvin_gui import KelvinGUI

root = tk.Tk()
root.withdraw()  # hide empty root window

model = TemperatureModel()

slider = SliderGUI(model, 50, 50)
fahrenheit = FahrenheitGUI(model, 300, 50)
gauge = GaugeGUI(model, 550, 50)
CelsiusGUI(model, 1050, 50)
KelvinGUI(model, 1300, 50)

root.mainloop()