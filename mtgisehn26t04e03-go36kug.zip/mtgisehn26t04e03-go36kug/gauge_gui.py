import sys
from typing import Optional
import tkinter as tk
from .observer import Observer
from .temperature_model import TemperatureModel


class GaugeGUI(Observer[float]):

    WIDTH = 220
    HEIGHT = 300

    MIN_VALUE = -20
    MAX_VALUE = 150

    CANVAS_LEFT = 100
    CANVAS_TOP = 20
    CANVAS_W = 20
    CANVAS_H = 200

    def __init__(self, model: TemperatureModel, x: int, y: int):
        self.__model = model
        self._current_value: int = 0
        self.__x = x
        self.__y = y

        self._window: Optional[tk.Toplevel] = None
        self._canvas: Optional[tk.Canvas] = None

        self._create_ui()
        self.__model.add_observer(self)


    def _create_ui(self) -> None:
        self._window = tk.Toplevel()
        self._window.title("Temperature Gauge")
        self._window.geometry(f"{self.WIDTH}x{self.HEIGHT}+{self.__x}+{self.__y}")
        self._window.protocol("WM_DELETE_WINDOW", self._on_close)

        self._canvas = tk.Canvas(
            self._window,
            width=self.WIDTH,
            height=self.HEIGHT,
            bg="white"
        )
        self._canvas.pack(fill=tk.BOTH, expand=True)

        self._repaint()

    def _on_close(self) -> None:
        self._window.destroy()
        sys.exit(0)

    def on_update(self, new_state: float) -> None:
        self.set_current_value(int(new_state))
        self._repaint()

    def set_current_value(self, level: int) -> None:
        self._current_value = level

    def get_current_value(self) -> int:
        return self._current_value

  
    # Drawing logic
    def _repaint(self) -> None:
        if self._canvas is None:
            return

        c = self._canvas
        c.delete("all")

        fill_color = "red" if self._current_value > 0 else "blue"

        # Tube outline
        c.create_rectangle(
            self.CANVAS_LEFT,
            self.CANVAS_TOP,
            self.CANVAS_LEFT + self.CANVAS_W,
            self.CANVAS_TOP + self.CANVAS_H,
            outline="black",
            fill="white"
        )

        # Bulb
        bulb_x = self.CANVAS_LEFT - self.CANVAS_W // 2
        bulb_y = self.CANVAS_TOP + self.CANVAS_H - self.CANVAS_W // 3

        c.create_oval(
            bulb_x,
            bulb_y,
            bulb_x + self.CANVAS_W * 2,
            bulb_y + self.CANVAS_W * 2,
            fill=fill_color,
            outline="black"
        )

        # Clamp value
        clamped = max(self.MIN_VALUE, min(self.MAX_VALUE, self._current_value))

        # Fill calculation
        fill_top = self.CANVAS_H * (clamped - self.MAX_VALUE) / (
            self.MIN_VALUE - self.MAX_VALUE
        )

        c.create_rectangle(
            self.CANVAS_LEFT + 1,
            self.CANVAS_TOP + fill_top,
            self.CANVAS_LEFT + self.CANVAS_W - 1,
            self.CANVAS_TOP + self.CANVAS_H,
            fill=fill_color,
            outline=""
        )