from .temperature_gui import TemperatureGUI
from .temperature_model import TemperatureModel
from .temperature_converter import TemperatureConverter


class KelvinGUI(TemperatureGUI):

    def __init__(self, model: TemperatureModel, x: int, y: int):
        super().__init__("Kelvin Temperature", model, x, y)
        self.add_raise_temp_listener(lambda: self.get_model().increase_kelvin(1.0))
        self.add_lower_temp_listener(lambda: self.get_model().increase_kelvin(-1.0))
        self.add_display_listener(lambda: self.get_model().set_temperature_kelvin(self.get_display()))

    def on_update(self, new_state: float) -> None:
        self.set_display(str(TemperatureConverter.convert_celsius_to_kelvin(new_state)))
