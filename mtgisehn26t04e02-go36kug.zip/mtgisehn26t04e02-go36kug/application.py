from datetime import datetime, timedelta

try:
    from .drivers_license import DriversLicense
    from .e_bike import EBike
    from .rider import Rider
except ImportError:
    from drivers_license import DriversLicense
    from e_bike import EBike
    from rider import Rider


class Application:
    @staticmethod
    def main():
        now = datetime.now()

        rider1 = Rider("A", 19, True, DriversLicense(now + timedelta(days=365 * 5), "A"))
        rider2 = Rider("B", 22, True, None)

        pev = EBike(100, "XYZ42")

        rental1 = pev.rent(now, now + timedelta(seconds=20), rider1)
        rental2 = pev.rent(now + timedelta(seconds=30), now + timedelta(seconds=60), rider2)

        # rider2 subscribes for updates on PEV XYZ42
        pev.subscribe(rider2)

        rental1.start()
        # time passes...
        rental1.stop()

        # rider2 knows they can use PEV XYZ42
        pev.unsubscribe(rider2)
        rental2.start()


if __name__ == "__main__":
    Application.main()
