from abc import ABC, abstractmethod
from typing import Generic, TypeVar


T = TypeVar("T")


class Observer(ABC, Generic[T]):
    @abstractmethod
    def update(self, update: T) -> None:
        pass
