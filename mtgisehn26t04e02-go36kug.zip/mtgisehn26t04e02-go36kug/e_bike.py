try:
    from .pev import PEV
except ImportError:
    from pev import PEV


class EBike(PEV):
    def __init__(self, charge_level, license_plate):
        super().__init__(charge_level, license_plate)
        self._price_per_minute = 3

    def __str__(self):
        return (
            "E-Bike "
            + self.get_license_plate()
            + " with charge level of "
            + str(self.get_charge_level())
        )
