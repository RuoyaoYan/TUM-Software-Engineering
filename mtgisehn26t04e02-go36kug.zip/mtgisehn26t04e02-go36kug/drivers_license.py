class DriversLicense:
    def __init__(self, valid_until, name):
        self.__valid_until = valid_until
        self.__name = name

    def get_valid_until(self):
        return self.__valid_until

    def get_name(self):
        return self.__name
