from datetime import datetime, timedelta

try:
    from .drivers_license import DriversLicense
    from .observer import Observer
    from .pev_availability_update import PEVAvailabilityUpdate
except ImportError:
    from drivers_license import DriversLicense
    from observer import Observer
    from pev_availability_update import PEVAvailabilityUpdate


class Rider(Observer[PEVAvailabilityUpdate]):
    def __init__(self, name, age, has_helmet, drivers_license):
        self.__name = name
        self.__age = age
        self.__has_helmet = has_helmet
        self.__drivers_license = drivers_license
        self.__pev = None
        self.__rentals = []

    def get_name(self):
        return self.__name

    def get_age(self):
        return self.__age

    def set_age(self, age):
        self.__age = age

    def has_helmet(self):
        return self.__has_helmet

    def set_has_helmet(self, has_helmet):
        self.__has_helmet = has_helmet

    def get_pev(self):
        return self.__pev

    def is_has_helmet(self):
        return self.__has_helmet

    def set_pev(self, pev):
        self.__pev = pev

    def get_drivers_license(self):
        return self.__drivers_license

    def get_rentals(self):
        return tuple(self.__rentals)

    def receive_drivers_license(self):
        self.__drivers_license = DriversLicense(
            datetime.now() + timedelta(days=365 * 10),
            self.__name,
        )

    def rent(self, pev, from_time, to_time):
        try:
            rental = pev.rent(from_time, to_time, self)
            self.__rentals.append(rental)
        except ValueError:
            print("Couldn't book the pev since it is already booked")

    def update(self, update: PEVAvailabilityUpdate) -> None:
        self.__notify_availability_changed(update.get_pev(), update.is_available())

    def __notify_availability_changed(self, pev, is_available):
        status = "available" if is_available else "not available"
        print(self.__name + " got notified that " + pev.get_license_plate() + " is now " + status)
