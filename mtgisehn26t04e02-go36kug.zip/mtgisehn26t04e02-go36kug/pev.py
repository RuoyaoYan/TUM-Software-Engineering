from abc import abstractmethod

try:
    from .pev_availability_update import PEVAvailabilityUpdate
    from .subject import Subject
except ImportError:
    from pev_availability_update import PEVAvailabilityUpdate
    from subject import Subject


class PEV(Subject[PEVAvailabilityUpdate]):
    def __init__(self, charge_level, license_plate):
        super().__init__()
        self.__charge_level = charge_level
        self.__license_plate = license_plate
        self.__available = True
        self._price_per_minute = 0
        self.__rentals = []

    @abstractmethod
    def __str__(self):
        pass

    def get_license_plate(self):
        return self.__license_plate

    def get_charge_level(self):
        return self.__charge_level

    def set_charge_level(self, charge_level):
        self.__charge_level = charge_level

    def is_available(self):
        return self.__available

    def get_rentals(self):
        return self.__rentals

    def lock(self):
        if not self.__available:
            raise RuntimeError("Already locked")
        self.__available = False
        self._notify_observers()

    def unlock(self):
        if self.__available:
            raise RuntimeError("Already unlocked")
        self.__available = True
        self._notify_observers()

    def _get_update(self) -> PEVAvailabilityUpdate:
        return PEVAvailabilityUpdate(self, self.__available)

    def get_price_per_minute(self):
        return self._price_per_minute

    def charge_up(self):
        if self.__charge_level < 100:
            self.__charge_level += 1

    def rent(self, from_time, to_time, rider):
        if self.__is_booked(from_time, to_time):
            raise ValueError("Already booked!")

        try:
            from .rental import Rental
        except ImportError:
            from rental import Rental

        rental = Rental(from_time, to_time, self, rider)
        self.__rentals.append(rental)
        return rental

    def __is_booked(self, from_time, to_time):
        return any(
            from_time < rental.get_to() and rental.get_from() < to_time
            for rental in self.__rentals
        )

    def ride(self):
        print("Riding " + str(self))
