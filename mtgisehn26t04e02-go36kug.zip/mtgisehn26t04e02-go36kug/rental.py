from datetime import datetime


class Rental:
    def __init__(self, from_time, to_time, rented_pev, rider):
        if from_time > to_time:
            raise ValueError()

        self.__from = from_time
        self.__to = to_time
        self.__rented_pev = rented_pev
        self.__rider = rider

    def time_elapsed(self):
        return int((self.__to - self.__from).total_seconds())

    def start(self):
        if abs((datetime.now() - self.__from).total_seconds()) > 60:
            raise RuntimeError("May not start the rental now!")
        self.__rented_pev.lock()
        self.__rider.set_pev(self.__rented_pev)

    def stop(self):
        self.__rented_pev.unlock()
        self.__rider.set_pev(None)

    def get_from(self):
        return self.__from

    def get_to(self):
        return self.__to

    def get_rented_pev(self):
        return self.__rented_pev
