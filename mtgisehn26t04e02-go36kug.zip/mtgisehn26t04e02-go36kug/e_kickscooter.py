try:
    from .pev import PEV
except ImportError:
    from pev import PEV


class EKickscooter(PEV):
    def __init__(self, charge_level, license_plate):
        super().__init__(charge_level, license_plate)
        self._price_per_minute = 2

    def __str__(self):
        return (
            "E-Kickscooter "
            + self.get_license_plate()
            + " with charge level of "
            + str(self.get_charge_level())
        )
