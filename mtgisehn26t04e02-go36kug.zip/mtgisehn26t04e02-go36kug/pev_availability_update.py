class PEVAvailabilityUpdate:
    def __init__(self, pev, is_available: bool):
        self.__pev = pev
        self.__available = is_available

    def get_pev(self):
        return self.__pev

    def is_available(self) -> bool:
        return self.__available
