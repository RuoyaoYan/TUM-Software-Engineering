from abc import ABC, abstractmethod
from typing import Generic, TypeVar

try:
    from .observer import Observer
except ImportError:
    from observer import Observer


T = TypeVar("T")


class Subject(ABC, Generic[T]):
    def __init__(self):
        self.__observers: list[Observer[T]] = []

    def subscribe(self, observer: Observer[T]) -> None:
        self.__observers.append(observer)

    def unsubscribe(self, observer: Observer[T]) -> None:
        self.__observers.remove(observer)

    def _notify_observers(self) -> None:
        update = self._get_update()
        for observer in self.__observers:
            observer.update(update)

    @abstractmethod
    def _get_update(self) -> T:
        pass
