from enum import Enum


class Units(Enum):
    M = "M"
    CM = "CM"
    KM = "KM"
    I = "I"
