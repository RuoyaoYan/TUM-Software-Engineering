import unittest

try:
    from .measurement import Measurement
    from .units import Units
except ImportError:
    from measurement import Measurement
    from units import Units


class MeasurementTest(unittest.TestCase):
    __test__ = False

    def test_simple_add(self):
        a = Measurement(3, Units.M)
        b = Measurement(5, Units.M)
        self.assertEqual(Measurement(8, Units.M), a.add(b))

    def test_simple_subtract(self):
        a = Measurement(10, Units.M)
        b = Measurement(4, Units.M)
        self.assertEqual(Measurement(6, Units.M), a.subtract(b))

    def test_invalid_add(self):
        a = Measurement(3, Units.M)
        b = Measurement(5, Units.CM)
        with self.assertRaises(ValueError):
            a.add(b)
