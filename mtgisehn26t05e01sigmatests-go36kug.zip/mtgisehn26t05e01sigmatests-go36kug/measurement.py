try:
    from .units import Units
except ImportError:
    from units import Units


class Measurement:
    def __init__(self, distance: int, units: Units):
        self.__distance = distance
        self.__units = units

    def add(self, measurement):
        if self.__units != measurement.__units:
            raise ValueError("Units must be identical")
        return Measurement(self.__distance + measurement.__distance, self.__units)

    def subtract(self, measurement):
        if self.__units != measurement.__units:
            raise ValueError("Units must be identical")
        return Measurement(self.__distance - measurement.__distance, self.__units)

    def __eq__(self, other):
        if self is other:
            return True
        if other is None:
            return False
        if type(self) is not type(other):
            return False
        return (
            self.__distance == other.__distance
            and self.__units == other.__units
        )

    def __hash__(self):
        return hash((self.__distance, self.__units))
