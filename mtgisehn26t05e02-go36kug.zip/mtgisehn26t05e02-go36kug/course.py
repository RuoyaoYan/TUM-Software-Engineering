from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    try:
        from .student import Student  
    except ImportError:
        from student import Student
    


class Course(ABC):

    @abstractmethod
    def enroll(self, student: "Student") -> bool:
        pass

    @abstractmethod
    def drop(self) -> None:
        pass

    @abstractmethod
    def start(self) -> None:
        pass