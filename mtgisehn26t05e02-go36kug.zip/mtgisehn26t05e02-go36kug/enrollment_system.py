try:
    from .student import Student
    from .course import Course
except ImportError:
    from student import Student
    from course import Course
    
class EnrollmentSystem:

    def enroll(self, student: "Student", course: "Course") -> None:
        if course.enroll(student):
            student.add_course(course)
           