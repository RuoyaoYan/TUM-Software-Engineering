import unittest
from unittest.mock import Mock, create_autospec
try:
    from .enrollment_system import EnrollmentSystem
    from .student import Student
    from .course import Course
except ImportError:
    from enrollment_system import EnrollmentSystem
    from student import Student
    from course import Course


class TestEnrollmentSystem(unittest.TestCase):

    def setUp(self):
        self.enrollment_system = EnrollmentSystem()
        self.course_mock = create_autospec(Course)

    def test_enroll_successful(self):
        student = Student()
        self.course_mock.enroll.return_value = True

        self.enrollment_system.enroll(student, self.course_mock)

        self.course_mock.enroll.assert_called_once_with(student)
        self.assertIn(self.course_mock, student.get_courses())

    def test_enroll_unsuccessful(self):
        student = Student()
        self.course_mock.enroll.return_value = False

        self.enrollment_system.enroll(student, self.course_mock)

        self.course_mock.enroll.assert_called_once_with(student)
        self.assertEqual([], student.get_courses())

if __name__ == "__main__":
    unittest.main()



