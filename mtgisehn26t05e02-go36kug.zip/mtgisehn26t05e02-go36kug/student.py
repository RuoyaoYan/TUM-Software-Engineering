from typing import TYPE_CHECKING, List

if TYPE_CHECKING:
    try:
        from .course import Course  
    except ImportError:
        from course import Course

class Student:

    def __init__(self) -> None:
        self.__courses: List["Course"] = []

    def get_courses(self) -> List["Course"]:
        return self.__courses
        
    def add_course(self, course: "Course") -> None:
        self.__courses.append(course)

   