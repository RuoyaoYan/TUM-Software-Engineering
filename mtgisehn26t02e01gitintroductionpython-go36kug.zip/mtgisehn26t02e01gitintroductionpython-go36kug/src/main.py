print("Hello, Git!")
print("I survived the first semester at TUM!!!")npm install -g @anthropic-ai/claude-code
print("hello")