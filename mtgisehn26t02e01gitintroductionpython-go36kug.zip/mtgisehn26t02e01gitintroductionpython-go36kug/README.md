# SE Git Intro (Python)
This repository is for learning the basics of Git and Python project structure.
This line was added in branch A.
This line was added in branch B.git 