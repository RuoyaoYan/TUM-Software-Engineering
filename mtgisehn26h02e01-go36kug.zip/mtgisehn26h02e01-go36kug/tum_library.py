class TUMLibrary:
    """
    Represents a library with multiple sections, where each section contains
    shelves that store books organized by genre.
    """

    def __init__(self, name):
        self._name = name
        self._section_array = [None] * 5

    def add_section(self, section):
        """
        Adds a new section to the library if the section array is not full.
        """
        for i in range(len(self._section_array)):
            if self._section_array[i] is None:
                self._section_array[i] = section
                return

    def validate_new_book(self, new_book):
        """
        Validates and adds a new book to the appropriate section and shelf based
        on the book's genre. Duplicate IDs in the matching section are rejected.
        """
        matching_section = None
        for section in self._section_array:
            if section is not None and section.get_section_name() == new_book.get_genre():
                matching_section = section
                break

        if matching_section is None:
            return False

        for shelf in matching_section.get_shelf_array():
            if shelf is None:
                continue
            for book in shelf.get_book_array():
                if book is not None and book.get_id() == new_book.get_id():
                    return False

        return matching_section.add_to_shelf(new_book)

    def sort(self):
        """
        Sorts all books in each shelf of each section alphabetically by title
        using bubble sort.
        """
        for section in self._section_array:
            if section is None:
                continue

            for shelf in section.get_shelf_array():
                if shelf is None or shelf.get_book_array() is None:
                    continue

                books = shelf.get_book_array()
                n = len(books)
                for i in range(n - 1):
                    for j in range(n - 1 - i):
                        a = books[j]
                        b = books[j + 1]
                        if a is None and b is None:
                            continue
                        if a is None:
                            books[j], books[j + 1] = books[j + 1], books[j]
                        elif b is not None and a.get_title() > b.get_title():
                            books[j], books[j + 1] = books[j + 1], books[j]

    def get_name(self):
        return self._name

    def set_name(self, name):
        self._name = name

    def get_section_array(self):
        return self._section_array

    def set_section_array(self, section_array):
        self._section_array = section_array

    def __str__(self):
        return (
            "TUMLibrary {\n"
            f"name: {self._name}, \n"
            f"Section: {self._section_array}\n"
            "}"
        )
