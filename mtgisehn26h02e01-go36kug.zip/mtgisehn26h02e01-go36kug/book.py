class Book:
    """
    Represents a book with attributes such as title, author, publisher, year of
    publication, genre, and a unique identifier.
    """

    def __init__(self, title, author, publisher, year, genre, id):
        self._title = title
        self._author = author
        self._publisher = publisher
        self._year = year
        self._genre = genre
        self._id = id

    def get_title(self):
        return self._title

    def set_title(self, title):
        self._title = title

    def get_author(self):
        return self._author

    def set_author(self, author):
        self._author = author

    def get_publisher(self):
        return self._publisher

    def set_publisher(self, publisher):
        self._publisher = publisher

    def get_year(self):
        return self._year

    def set_year(self, year):
        self._year = year

    def get_genre(self):
        return self._genre

    def set_genre(self, genre):
        self._genre = genre

    def get_id(self):
        return self._id

    def __str__(self):
        return f"{self._title}-{self._id}"
