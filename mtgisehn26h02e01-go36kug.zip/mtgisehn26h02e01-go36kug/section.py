from shelf import Shelf


class Section:
    """
    Represents a section within a library, defined by a name and containing
    multiple shelves.
    """

    def __init__(self, section_name):
        self._section_name = section_name
        self._shelf_array = [None] * 5

    def add_to_shelf(self, new_book):
        """
        Attempts to add a new book to the first available shelf in the section.
        Creates a new shelf if necessary.
        """
        for i in range(len(self._shelf_array)):
            if self._shelf_array[i] is None:
                new_shelf = Shelf(self)
                new_shelf.add_book(new_book)
                self._shelf_array[i] = new_shelf
                return True
            if not self._shelf_array[i].is_utilized():
                return self._shelf_array[i].add_book(new_book)
        return False

    def get_section_name(self):
        return self._section_name

    def set_section_name(self, section_name):
        self._section_name = section_name

    def get_shelf_array(self):
        return self._shelf_array

    def set_shelf_array(self, shelf_array):
        self._shelf_array = shelf_array

    def __str__(self):
        return f"{self._section_name} {self._shelf_array}\n"
