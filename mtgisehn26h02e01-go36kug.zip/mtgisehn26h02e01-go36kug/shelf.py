class Shelf:
    """
    Represents a shelf within a section. A shelf can hold a fixed number of
    books.
    """

    def __init__(self, section):
        self._section = section
        self._book_array = [None] * 15

    def is_utilized(self):
        """
        Checks whether the shelf contains no empty slots for books.
        """
        for slot in self._book_array:
            if slot is None:
                return False
        return True

    def add_book(self, new_book):
        """
        Attempts to add a book to the first available slot on the shelf.
        """
        for i in range(len(self._book_array)):
            if self._book_array[i] is None:
                self._book_array[i] = new_book
                return True
        return False

    def get_section(self):
        return self._section

    def set_section(self, section):
        self._section = section

    def get_book_array(self):
        return self._book_array

    def set_book_array(self, book_array):
        self._book_array = book_array

    def __str__(self):
        return f"Books: {self._book_array}\n"
