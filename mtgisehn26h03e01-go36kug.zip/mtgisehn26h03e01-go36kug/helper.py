try:
    from .list_node import ListNode
except ImportError:
    from list_node import ListNode


class Helper:
    @staticmethod
    def merge_lists(list1, list2):
        dummy = ListNode(0)
        current = dummy

        while list1 is not None and list2 is not None:
            if list1.val <= list2.val:
                current.next = list1
                list1 = list1.next
            else:
                current.next = list2
                list2 = list2.next
            current = current.next

        current.next = list1 if list1 is not None else list2

        return dummy.next
