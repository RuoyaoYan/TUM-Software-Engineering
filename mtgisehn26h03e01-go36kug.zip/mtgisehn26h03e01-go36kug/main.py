def main():
    # TODO: Test your code here. However, this is not part of the grade.
    print("Hello World!")


if __name__ == "__main__":
    main()


#1