from animal import Animal
from rideable import Rideable


class Pig(Animal, Rideable):
    def __init__(self, name: str = ""):
        super().__init__(name)

    def message_on_feed(self) -> str:
        return "Oink! "

    def message_on_ride(self) -> str:
        return f"Riding on Pig {self.get_name()}"
