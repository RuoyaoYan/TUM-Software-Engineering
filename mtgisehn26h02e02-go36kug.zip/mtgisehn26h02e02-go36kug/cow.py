from animal import Animal
from rideable import Rideable
from milkable import Milkable


class Cow(Animal, Rideable, Milkable):
    def __init__(self, name: str = ""):
        super().__init__(name)

    def message_on_feed(self) -> str:
        return "Mooh! "

    def message_on_milk(self) -> str:
        return f"Cow {self.get_name()} is milked"

    def message_on_ride(self) -> str:
        return f"Riding on Cow {self.get_name()}"
