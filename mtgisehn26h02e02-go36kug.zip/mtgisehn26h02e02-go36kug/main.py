from cow import Cow
from pig import Pig
from goat import Goat
from farm import Farm


def main():
    cow = Cow("Bessie")
    pig = Pig("Porky")
    goat = Goat("Billy")

    farm = Farm()
    farm.add_animal(cow)
    farm.add_animal(pig)
    farm.add_animal(goat)

    farm.sing_farm_song()


if __name__ == "__main__":
    main()
