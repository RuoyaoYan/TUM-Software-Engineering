from animal import Animal
from milkable import Milkable


class Goat(Animal, Milkable):
    def __init__(self, name: str = ""):
        super().__init__(name)

    def message_on_feed(self) -> str:
        return "Maah! "

    def message_on_milk(self) -> str:
        return f"Goat {self.get_name()} is milked"
