from abc import ABC, abstractmethod


class Milkable(ABC):
    @classmethod
    def __subclasshook__(cls, C):
        if cls is Milkable:
            if hasattr(C, 'message_on_milk'):
                return True
        return NotImplemented

    @abstractmethod
    def message_on_milk(self) -> str:
        pass
