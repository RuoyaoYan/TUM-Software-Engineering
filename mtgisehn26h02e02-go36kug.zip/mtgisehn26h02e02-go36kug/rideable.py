from abc import ABC, abstractmethod


class Rideable(ABC):
    @classmethod
    def __subclasshook__(cls, C):
        if cls is Rideable:
            if hasattr(C, 'message_on_ride'):
                return True
        return NotImplemented

    @abstractmethod
    def message_on_ride(self) -> str:
        pass
