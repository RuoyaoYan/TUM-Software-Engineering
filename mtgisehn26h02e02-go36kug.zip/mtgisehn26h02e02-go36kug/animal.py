from abc import ABC, abstractmethod


class Animal(ABC):
    def __init__(self, name: str = ""):
        self._name = name

    def get_name(self) -> str:
        return self._name

    def set_name(self, name: str):
        self._name = name

    @classmethod
    def __subclasshook__(cls, C):
        if cls is Animal:
            if hasattr(C, 'message_on_feed'):
                return True
        return NotImplemented

    @abstractmethod
    def message_on_feed(self) -> str:
        pass
