from animal import Animal


class Farm:
    def __init__(self):
        self._animals = []

    def get_animals(self):
        return self._animals

    def set_animals(self, animals):
        self._animals = animals

    def add_animal(self, animal: Animal) -> None:
        self._animals.append(animal)

    def _sing_farm_song_verse(self, animal: Animal) -> None:
        sound = animal.message_on_feed()
        animal_type = type(animal).__name__

        print("Old MacDonald had a farm Ee i ee i o")
        print(f"And on his farm he had some {animal_type}s Ee i ee i oh")
        print(f"With a {sound}{sound}here, and a {sound}{sound}there.")
        print(f"Here a {sound}There a {sound}")
        print(f"Everywhere a {sound}{sound}")
        print("Old MacDonald had a farm Ee i ee i o")

    def sing_farm_song(self) -> None:
        for animal in self._animals:
            self._sing_farm_song_verse(animal)

    def feed_all_animals(self) -> None:
        for animal in self._animals:
            print(animal.message_on_feed())
