from time import sleep

try:
    from .current_conditions_view import CurrentConditionsView
    from .weather_data import WeatherData
except ImportError:
    from current_conditions_view import CurrentConditionsView
    from weather_data import WeatherData


class WeatherController:
    @staticmethod
    def main():
        weather_data = WeatherData()
        current_view = CurrentConditionsView()

        weather_data.add_observer(current_view)

        weather_data.set_weather_data(15.0, 65.0, 1000.0)
        sleep(1)

        weather_data.set_weather_data(18.0, 60.5, 1010.0)
        sleep(1)

        weather_data.set_weather_data(20.0, 70.2, 1010.0)


if __name__ == "__main__":
    WeatherController.main()
