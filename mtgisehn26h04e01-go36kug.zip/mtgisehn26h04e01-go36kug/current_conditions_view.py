try:
    from .observer import Observer
except ImportError:
    from observer import Observer


class CurrentConditionsView(Observer):
    def __init__(self):
        self.__weather = None

    def update(self, weather, pressure_trend):
        self.__weather = weather
        self.__display(pressure_trend)

    def __display(self, pressure_trend):
        print("Current Conditions:")
        print(f"Temperature: {self.__weather.get_temperature()}C")
        print(f"Humidity: {self.__weather.get_humidity()}%")
        print(f"Pressure: {self.__weather.get_pressure()} hPa. Pressure trend: {pressure_trend}")
        print("-----")
