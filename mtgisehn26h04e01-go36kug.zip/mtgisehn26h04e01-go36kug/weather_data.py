from collections import deque

try:
    from .weather import Weather
except ImportError:
    from weather import Weather


class WeatherData:
    __HISTORY_LIMIT = 2

    def __init__(self):
        self.__observers = []
        self.__history = deque()
        self.__weather = None

    def add_observer(self, observer):
        self.__observers.append(observer)

    def remove_observer(self, observer):
        self.__observers.remove(observer)

    def set_weather_data(self, temperature, humidity, pressure):
        self.__weather = Weather(temperature, humidity, pressure)
        self.__update_history(self.__weather)
        self.__notify_observers()

    def __update_history(self, weather):
        if len(self.__history) >= self.__HISTORY_LIMIT:
            self.__history.popleft()
        self.__history.append(weather)

    def __calculate_pressure_trend(self):
        if len(self.__history) < 2:
            return "Stable"
        diff = self.__history[-1].get_pressure() - self.__history[0].get_pressure()
        if diff > 1:
            return "Rising"
        elif diff < -1:
            return "Falling"
        return "Stable"

    def __notify_observers(self):
        pressure_trend = self.__calculate_pressure_trend()
        for observer in self.__observers:
            observer.update(self.__weather, pressure_trend)

    def get_weather(self):
        return self.__weather
